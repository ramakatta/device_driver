#include<iostream>
int main()
{
  std::cout<<"CMAKE test"<<std::endl;
  return 0;
}
