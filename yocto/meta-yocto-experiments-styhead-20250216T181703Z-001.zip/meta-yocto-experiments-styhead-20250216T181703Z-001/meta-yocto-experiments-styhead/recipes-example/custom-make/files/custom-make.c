#include <stdio.h>
int main(void)
{
  printf("Hello world using Makefile\n");
  return 0;
}

