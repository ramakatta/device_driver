#include <stdio.h>
//#include <SAMPLE/libsample.h>
#include <SAMPLE/libsample.h>
int main(void)
{
function();
samplelib();
return 0;
}

