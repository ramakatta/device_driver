#include <stdio.h>
#include "libsample.h"
void function()
{
 printf("Hello World!\n");
}
void samplelib()
{
 printf("Hello From Vector!!! -- samplelib !\n");
}

